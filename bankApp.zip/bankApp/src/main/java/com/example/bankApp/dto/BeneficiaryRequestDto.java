package com.example.bankApp.dto;

import org.springframework.stereotype.Component;

@Component
public class BeneficiaryRequestDto {
	String myAccountNumber;
	String beneficiaryAccountNumber;
	String beneficiaryName;
	
	public String getMyAccountNumber() {
		return myAccountNumber;
	}
	public void setMyAccountNumber(String myAccountNumber) {
		this.myAccountNumber = myAccountNumber;
	}
	public String getBeneficiaryAccountNumber() {
		return beneficiaryAccountNumber;
	}
	public void setBeneficiaryAccountNumber(String beneficiaryAccountNumber) {
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
	}
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	

}
