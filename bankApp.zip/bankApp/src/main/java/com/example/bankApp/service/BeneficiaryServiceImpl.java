package com.example.bankApp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.bankApp.dao.AccountRepository;
import com.example.bankApp.dao.BeneficiaryRepository;
import com.example.bankApp.dto.BeneficiaryRequestDto;
import com.example.bankApp.globalExceptionHandler.ResourceNotFoundException;
import com.example.bankApp.model.Account;
import com.example.bankApp.model.Payee;
import com.example.bankApp.model.PayeeBeneficiaryKey;

@Service
public class BeneficiaryServiceImpl implements BeneficiaryService {
	@Autowired
	AccountRepository accountRepository;
	@Autowired
	BeneficiaryRepository beneficiaryRepository;

	// HttpSession session;

	/* save beneficiary details */
	@Override
	public void saveBeneficiaryDetails(BeneficiaryRequestDto beneficiaryDto) {
		
		Account beneficiaryAccount=accountRepository.findByAccountNumber(beneficiaryDto.getBeneficiaryAccountNumber());
		if(beneficiaryAccount==null)
			throw new ResourceNotFoundException("Customer Number not found");
		
		Payee payee = new Payee();
		PayeeBeneficiaryKey payeeBeneficiaryKey = new PayeeBeneficiaryKey();

		payeeBeneficiaryKey.setMyAccountNumber(beneficiaryDto.getMyAccountNumber());
		payeeBeneficiaryKey.setBeneficiaryAccountNumber(beneficiaryDto.getBeneficiaryAccountNumber());

		payee.setBeneficiaryName(beneficiaryDto.getBeneficiaryName());
		payee.setPayeeBeneficiaryKey(payeeBeneficiaryKey);

		beneficiaryRepository.save(payee);

	}

}
