package com.example.bankApp.model;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class PayeeBeneficiaryKey implements Serializable{
	private static final long serialVersionUID = 1L;

	private String myAccountNumber;
	
	private String beneficiaryAccountNumber;
	public String getMyAccountNumber() {
		return myAccountNumber;
	}
	public void setMyAccountNumber(String myAccountNumber) {
		this.myAccountNumber = myAccountNumber;
	}
	public String getBeneficiaryAccountNumber() {
		return beneficiaryAccountNumber;
	}
	public void setBeneficiaryAccountNumber(String beneficiaryAccountNumber) {
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
	}
	

}
