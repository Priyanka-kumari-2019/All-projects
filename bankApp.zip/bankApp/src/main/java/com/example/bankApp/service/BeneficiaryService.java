package com.example.bankApp.service;

import com.example.bankApp.dto.BeneficiaryRequestDto;

public interface BeneficiaryService {
	
	public void saveBeneficiaryDetails(BeneficiaryRequestDto beneficiaryDto);
	
	
	

}
