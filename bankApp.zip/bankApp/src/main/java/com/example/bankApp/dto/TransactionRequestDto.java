package com.example.bankApp.dto;

import org.springframework.stereotype.Component;

@Component
public class TransactionRequestDto {
	String fromAccountNumber;
	String toAccountNumber;
	float amount;
	//String description;
	public String getFromAccountNumber() {
		return fromAccountNumber;
	}
	public void setFromAccountNumber(String fromAccountNumber) {
		this.fromAccountNumber = fromAccountNumber;
	}
	public String getToAccountNumber() {
		return toAccountNumber;
	}
	public void setToAccountNumber(String toAccountNumber) {
		this.toAccountNumber = toAccountNumber;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	/*
	 * public String getDescription() { return description; } public void
	 * setDescription(String description) { this.description = description; }
	 */
	
	

}
