package com.example.bankApp.model;

public class IdHelper {
	private static int customerId=100;
	public static int generateCustomerId() {
		customerId++;
		return customerId;
	}
	
	
	private static long accountNumber=2198100000L;
	public static long generateAccountNumber() {
		accountNumber++;
		return accountNumber;
	}

}
