package com.example.bankApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.bankApp.dto.AccountRequestDto;
import com.example.bankApp.service.AccountService;

@RestController
public class AccountController {
	
	@Autowired
	AccountService accountService;
	
	@PatchMapping("/account")
	public ResponseEntity<String> addBalance(@RequestBody AccountRequestDto accountDto) {

		accountService.updateBalance(accountDto);
		return ResponseEntity.ok("Balance updated Successfully");

	}

}
