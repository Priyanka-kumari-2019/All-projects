package com.example.bankApp.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
@Entity

public class Payee {
	@EmbeddedId
	PayeeBeneficiaryKey payeeBeneficiaryKey;;
	String beneficiaryName;
	public PayeeBeneficiaryKey getPayeeBeneficiaryKey() {
		return payeeBeneficiaryKey;
	}
	public void setPayeeBeneficiaryKey(PayeeBeneficiaryKey payeeBeneficiaryKey) {
		this.payeeBeneficiaryKey = payeeBeneficiaryKey;
	}
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	
}
