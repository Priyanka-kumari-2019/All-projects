package com.example.bankApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.bankApp.dto.BeneficiaryRequestDto;
import com.example.bankApp.service.BeneficiaryService;

@RestController
public class BeneficiaryController {
	@Autowired
	BeneficiaryService beneficiaryService;
	@PostMapping("/beneficiary")
	public ResponseEntity<String> addBeneficiary(@RequestBody BeneficiaryRequestDto beneficiaryRequestDto) {
		beneficiaryService.saveBeneficiaryDetails(beneficiaryRequestDto);
		return ResponseEntity.ok("Beneficiary added Successful");

	}

	
	

}
