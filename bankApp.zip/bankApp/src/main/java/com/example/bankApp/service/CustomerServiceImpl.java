package com.example.bankApp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.bankApp.dao.AccountRepository;
import com.example.bankApp.dao.CustomerRepository;
import com.example.bankApp.dto.CustomerRequestDto;
import com.example.bankApp.globalExceptionHandler.ResourceNotFoundException;
import com.example.bankApp.model.Customer;
import com.example.bankApp.model.IdHelper;

@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	AccountRepository bankRepository;
	@Autowired
	AccountService accountService;

	/*
	 * saves Customer Details getting CustomerDto Object and setting into Customer
	 */

	@Override
	public void saveCustomerDetails(CustomerRequestDto customerDto) {
		Customer customer = new Customer();
		customer.setId(IdHelper.generateCustomerId());
		customer.setName(customerDto.getName());
		customer.setAadharNumber(customerDto.getAadharNumber());
		customer.setAddress(customerDto.getAddress());
		customer.setDateOfBirth(customerDto.getDateOfBirth());
		customer.setEmailId(customerDto.getEmailId());
		customer.setPassword(customerDto.getPassword());
		customer.setPhoneNumber(customerDto.getPhoneNumber());
		Customer customerDetails = customerRepository.save(customer);

		accountService.saveAccountDetails(customerDetails.getId());

	}

	/* to show customer details */
	@Override
	public Iterable<Customer> getCustomerDetails() {
		return customerRepository.findAll();
	}
	
	

	/* validating customer using emailId and password */

	public ResponseEntity<String> validateCustomer(String loginId, String password) throws ResourceNotFoundException {

		Customer validCustomerDetails = customerRepository.findByEmailIdAndPassword(loginId, password);
		// session.setAttribute("loginCustomerDetails", validCustomerDetails);
		if (validCustomerDetails == null)
			return ResponseEntity.ok("valid Customer");

		else
			throw new ResourceNotFoundException("Customer Number not found");
	}

}
