package com.example.bankApp.service;

import com.example.bankApp.dto.AccountRequestDto;

public interface AccountService {
	public void saveAccountDetails(int customerId);
	public void updateBalance(AccountRequestDto accountDto);

}
