package com.example.bankApp.service;

import org.springframework.http.ResponseEntity;

import com.example.bankApp.dto.CustomerRequestDto;
import com.example.bankApp.globalExceptionHandler.ResourceNotFoundException;
import com.example.bankApp.model.Customer;

public interface CustomerService {
	public void saveCustomerDetails(CustomerRequestDto customerDto);
	public Iterable<Customer> getCustomerDetails();
	public ResponseEntity<String> validateCustomer(String loginId,String password) throws ResourceNotFoundException;
	
	//public void  saveBeneficiaryDetails(Payee payee); 
	

}
