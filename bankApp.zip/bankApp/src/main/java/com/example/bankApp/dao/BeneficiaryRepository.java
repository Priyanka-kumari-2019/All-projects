package com.example.bankApp.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.bankApp.model.Payee;
import com.example.bankApp.model.PayeeBeneficiaryKey;
@Repository
public interface BeneficiaryRepository extends CrudRepository<Payee, PayeeBeneficiaryKey>{
 
	public Payee findByPayeeBeneficiaryKey(PayeeBeneficiaryKey payeeBeneficiaryKey);
}
