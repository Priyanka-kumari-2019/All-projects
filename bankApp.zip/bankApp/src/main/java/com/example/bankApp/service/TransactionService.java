package com.example.bankApp.service;

import com.example.bankApp.dto.TransactionRequestDto;

public interface TransactionService {
	
	public void savetransactionDetails(TransactionRequestDto transactionDto);

}
