package com.example.bankApp.dto;

import org.springframework.stereotype.Component;

@Component
public class AccountRequestDto {
	String accountNumber;
	float amount;
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}

}
