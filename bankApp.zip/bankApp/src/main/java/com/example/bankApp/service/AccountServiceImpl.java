package com.example.bankApp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bankApp.dao.AccountRepository;
import com.example.bankApp.dto.AccountRequestDto;
import com.example.bankApp.globalExceptionHandler.ResourceNotFoundException;
import com.example.bankApp.model.Account;
import com.example.bankApp.model.IdHelper;

@Service
public class AccountServiceImpl implements AccountService {
	@Autowired
	AccountRepository bankRepository;

	/*
	 * saves Account Details passing customerId
	 */

	@Override
	public void saveAccountDetails(int customerId) {
		Account account = new Account();
		account.setCustomerId(customerId);
		account.setAccountNumber("SBI" + IdHelper.generateAccountNumber());
		account.setBalance(0);
		bankRepository.save(account);

	}

	/* update the balance in the account while credit or debit */

	@Override
	public void updateBalance(AccountRequestDto accountDto) {
		Account account = bankRepository.findByAccountNumber(accountDto.getAccountNumber());
		if (account == null)
			throw new ResourceNotFoundException("Account Number not found");

		account.setBalance(accountDto.getAmount());
		bankRepository.save(account);

	}

}
