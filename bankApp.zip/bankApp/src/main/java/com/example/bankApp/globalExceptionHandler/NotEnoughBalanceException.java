package com.example.bankApp.globalExceptionHandler;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class NotEnoughBalanceException extends RuntimeException {
public static final long serialVersionUID =1L;
	
	public NotEnoughBalanceException(final String message) {
		super(message);
	}

}
