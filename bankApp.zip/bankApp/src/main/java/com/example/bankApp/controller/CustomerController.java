package com.example.bankApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.bankApp.dto.CustomerRequestDto;
import com.example.bankApp.globalExceptionHandler.ResourceNotFoundException;
import com.example.bankApp.model.Customer;
import com.example.bankApp.service.CustomerService;

@RestController

public class CustomerController {

	@Autowired
	CustomerService bankService;

	@PostMapping("/customer")
	public String saveDetails(@RequestBody CustomerRequestDto customerDto) {

		bankService.saveCustomerDetails(customerDto);
		return "customer added successfully";

	}

	@GetMapping("/customer")
	public Iterable<Customer> getDetails() {
		return bankService.getCustomerDetails();
	}

	@GetMapping("/validate")
	public ResponseEntity<String> validateCustomer(@RequestParam(value = "emailId") String loginId,
			@RequestParam(value = "password") String password) throws ResourceNotFoundException {
		ResponseEntity<String> validCustomer = bankService.validateCustomer(loginId, password);

		return validCustomer;
	}

}
