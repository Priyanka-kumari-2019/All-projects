package com.example.bankApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.example.bankApp.dto.TransactionRequestDto;

import com.example.bankApp.service.TransactionService;

@RestController
public class TransactionController {
	@Autowired
	TransactionService transactionService;

	@PostMapping("/transaction")
	public ResponseEntity<String> doTransaction(@RequestBody TransactionRequestDto transactionDto) {

		transactionService.savetransactionDetails(transactionDto);
		return ResponseEntity.ok("Transaction Successful");

	}

}
