package com.example.bankApp.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.bankApp.dao.AccountRepository;
import com.example.bankApp.dao.BeneficiaryRepository;
import com.example.bankApp.dao.TransactionRepository;
import com.example.bankApp.dto.AccountRequestDto;
import com.example.bankApp.dto.TransactionRequestDto;
import com.example.bankApp.globalExceptionHandler.NotEnoughBalanceException;
import com.example.bankApp.globalExceptionHandler.ResourceNotFoundException;
import com.example.bankApp.model.Account;
import com.example.bankApp.model.Payee;
import com.example.bankApp.model.PayeeBeneficiaryKey;
import com.example.bankApp.model.Transaction;

@Service
public class TransactionServiceImpl implements TransactionService {
	@Autowired
	TransactionRepository transactionRepository;
	@Autowired
	AccountRepository bankRepository;
	@Autowired
	AccountService accountService;
	@Autowired
	BeneficiaryRepository beneficiaryRepository;

	/* saves Transaction details after credit or debit */
	@Override
	public void savetransactionDetails(TransactionRequestDto transactionDto) {

		Account toAccountDetails = bankRepository.findByAccountNumber(transactionDto.getToAccountNumber());
		PayeeBeneficiaryKey payeeBeneficiaryKey = new PayeeBeneficiaryKey();
		payeeBeneficiaryKey.setMyAccountNumber(transactionDto.getFromAccountNumber());
		payeeBeneficiaryKey.setBeneficiaryAccountNumber(transactionDto.getToAccountNumber());
		Payee payee = beneficiaryRepository.findByPayeeBeneficiaryKey(payeeBeneficiaryKey);

		if (toAccountDetails != null && payee != null) {
			Account account = bankRepository.findByAccountNumber(transactionDto.getFromAccountNumber());

			if (account.getBalance() > transactionDto.getAmount()) {

				Transaction transaction1 = new Transaction();
				Transaction transaction2 = new Transaction();

				transaction1.setAccountNumber(transactionDto.getToAccountNumber());
				transaction1.setAmount(transactionDto.getAmount());
				transaction1.setTransactionType("CREDIT");
				transaction1.setDescription("Rs " + transactionDto.getAmount() + " has been credited to your account");

				transaction2.setAccountNumber(transactionDto.getFromAccountNumber());
				transaction2.setAmount(transactionDto.getAmount());
				transaction2.setTransactionType("DEBIT");
				transaction2.setDescription("Rs " + transactionDto.getAmount() + " has been debited from your account");

				transactionRepository.save(transaction1);
				transactionRepository.save(transaction2);

				AccountRequestDto accountRequestDto = new AccountRequestDto();

				float remainingBalance = account.getBalance() - transactionDto.getAmount();
				float addedBalance = toAccountDetails.getBalance() + transactionDto.getAmount();

				accountRequestDto.setAccountNumber(transactionDto.getToAccountNumber());
				accountRequestDto.setAmount(addedBalance);
				accountService.updateBalance(accountRequestDto);

				accountRequestDto.setAccountNumber(transactionDto.getFromAccountNumber());
				accountRequestDto.setAmount(remainingBalance);
				accountService.updateBalance(accountRequestDto);

			} else
				throw new NotEnoughBalanceException("Not enough balance to do transaction");

		} else
			throw new ResourceNotFoundException("Account Number not found");

	}

}
