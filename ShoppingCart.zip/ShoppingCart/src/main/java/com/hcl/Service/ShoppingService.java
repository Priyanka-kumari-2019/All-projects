package com.hcl.Service;

import java.util.Calendar;
import java.util.List;
import java.util.Random;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.modal.Cart;
import com.hcl.modal.CartKey;
import com.hcl.modal.CustomerCartDetails;
import com.hcl.modal.CustomerOrder;
import com.hcl.modal.OrderKey;
import com.hcl.modal.OrderedProductDetails;
import com.hcl.Service.KeyHelper;
import com.hcl.modal.Product;
import com.hcl.modal.ShoppingCustomer;

@Service

public class ShoppingService {
	@Autowired
	private SessionFactory factory;

	/*
	 * public void saveCustomer(ShoppingCustomer customer) {
	 * factory.getCurrentSession().save(customer);
	 */
	public int saveCustomer(ShoppingCustomer customer) {
		 customer.setCustomerId(KeyHelper.getCustomerID());
		Session session = factory.openSession();
		Transaction tx = null;

		try {

			tx = session.beginTransaction();
			session.saveOrUpdate(customer);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return customer.getCustomerId();
	}

	public boolean validateCustomer(String userId, String pass) {

		Session session = factory.openSession();
		Transaction tx = null;
		boolean valid = false;
		try {

			tx = session.beginTransaction();
			Query query = session.createQuery("From ShoppingCustomer where emailId = ? and password= ?");
			query.setParameter(0, userId);
			query.setParameter(1, pass);
			List<String> list = query.list();
			tx.commit();
			if (list != null && (list.size() > 0))
				valid = true;

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return valid;
	}

	public void saveCustomerCartDetails(CustomerCartDetails custCartDetails) {

		Session session = factory.openSession();
		Transaction tx = null;

		try {

			tx = session.beginTransaction();
			session.saveOrUpdate(custCartDetails);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

	public List<Object[]> getCustomerID(String userId) {
		Session session = factory.openSession();
		Transaction tx = null;
		//int customerId = 0;
		List<Object[]> list=null;
		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("select s.customerId, s.name from ShoppingCustomer s where emailId=:code ");
			query.setParameter("code", userId);
			list=query.list();
			//customerId = (Integer) query.uniqueResult();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		//return customerId;
		return list;
	}

	public int getCartID(int customerID) {
		Session session = factory.openSession();
		Transaction tx = null;
		int cartId = 0;
		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("select cartId from CustomerCartDetails where customerId=:code ");
			query.setParameter("code", customerID);
			cartId = (Integer) query.uniqueResult();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

		return cartId;

	}

	public List<Product> getProductDetails() {

		Session session = factory.openSession();
		Transaction tx = null;
		List<Product> prod = null;

		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("FROM Product");

			prod = query.list();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

		return prod;

	}

	public void addCart(int cartId, int customerId, int productId, String productName) {

		Cart cart = new Cart();

		cart.setUserId(customerId);
		cart.setProductName(productName);

		CartKey ck = new CartKey();
		ck.setProductId(productId);
		ck.setCartId(cartId);

		cart.setCartProdId(ck);

		Session session = factory.openSession();
		Transaction tx = null;

		try {

			tx = session.beginTransaction();
			session.saveOrUpdate(cart);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}
	
	public Product getCartProductDetails(int prodId) {

		Session session = factory.openSession();
		Transaction tx = null;
		Product cartProd = null;

		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("from Product where productId=:code ");
			query.setParameter("code", prodId);
			cartProd =(Product) query.uniqueResult();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

		return cartProd;

	}

	/*public List<Cart> getMyCartDetails(int custId) {

		Session session = factory.openSession();
		Transaction tx = null;
		List<Cart> order = null;

		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("FROM Cart where userId= :code ");
			query.setParameter("code", custId);
			order = query.list();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

		return order;

	}*/

	public int placeOrder(int customerId, int cartId) {

		CustomerOrder order = new CustomerOrder();
		order.setStatus("OrderPlaced");
		order.setCartId(cartId);
		//order.setProductId(productId);
		order.setOrderId(KeyHelper.getOrderID());
		order.setCustomerId(customerId);
		Calendar c1 = Calendar.getInstance();
		System.out.println(c1.getTime());
		order.setOrderDate(c1.getTime());
		Session session = factory.openSession();
		Transaction tx = null;

		try {

			tx = session.beginTransaction();
			session.saveOrUpdate(order);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return order.getOrderId();
	}

	

	public List<Integer> getOrderProductId(int orderId) {

		Session session = factory.openSession();
		Transaction tx = null;
		List<Integer> productIds=null;

		try {
			tx = session.beginTransaction();
			Query query = session.createSQLQuery("select productId from OrderedProductDetails where orderId=:code ");
			query.setParameter("code", orderId);
			productIds =query.list();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

		return productIds;

	}
	
	
	
	public Product getOrderProductDetails(int prodId) {

		Session session = factory.openSession();
		Transaction tx = null;
		Product orderProd = null;

		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("from Product where productId=:code ");
			query.setParameter("code", prodId);
			orderProd =(Product) query.uniqueResult();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

		return orderProd;

	}
	

	public void deleteMyCart(int cartID) {

		Session session = factory.openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("delete from Cart where cartId=:code ");
			query.setParameter("code", cartID);
			query.executeUpdate();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}
	
	public void orderedProduct(int orderId,int productId) {

		Session session = factory.openSession();
		Transaction tx = null;
		
		OrderedProductDetails ordProdId=new OrderedProductDetails();
		OrderKey ordKey=new OrderKey();
		ordKey.setOrderId(orderId);
		ordKey.setProductId(productId);
		
		ordProdId.setOrderProductId(ordKey);
		try {
			tx = session.beginTransaction();
			 session.save(ordProdId);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}
	public CustomerOrder getOrderDetails(int ordId) {

		Session session = factory.openSession();
		Transaction tx = null;
		CustomerOrder ordDetails = null;

		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("from CustomerOrder where orderId=:code ");
			query.setParameter("code", ordId);
			ordDetails =(CustomerOrder) query.uniqueResult();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

		return ordDetails;

	}
	public void updateStatus(int orderId) {

		Session session = factory.openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("update CustomerOrder set status='delivered' where orderId=:code ");
			query.setParameter("code", orderId);
			query.executeUpdate();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}
	

}