package com.hcl.Service;

public class KeyHelper {
	private static int customerId=0;
	private static int cartId=0;
	private static int orderId=0;
	public static int getCustomerID() {
		customerId++;
		return customerId;
	}
	
	public static int getCartID() {
		cartId++;
		return cartId;
	}

	
	public static int getOrderID() {
		orderId++;
		return orderId;
	}
}
