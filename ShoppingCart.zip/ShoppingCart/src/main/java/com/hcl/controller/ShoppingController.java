package com.hcl.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.Service.KeyHelper;
import com.hcl.Service.ShoppingService;
import com.hcl.modal.Cart;
import com.hcl.modal.CustomerCartDetails;
import com.hcl.modal.CustomerOrder;
import com.hcl.modal.Product;
import com.hcl.modal.ShoppingCustomer;
import com.mysql.cj.Session;

@Controller

public class ShoppingController {
	@Autowired
	private ShoppingService shopService;

	@RequestMapping(value = "/entry")
	public String userRegisteration(Model model) {
		ShoppingCustomer customer = new ShoppingCustomer();
		model.addAttribute("customerDetails", customer);
		return "registeration";
	}

	CustomerCartDetails cartDetails = new CustomerCartDetails();

	@RequestMapping(value = "/submitForm", method = RequestMethod.POST)
	public String saveCust(@ModelAttribute("customerDetails") ShoppingCustomer customer, HttpSession session) {
		// customer.setCustomerId(KeyHelper.getCustomerID());
		int cust_id = shopService.saveCustomer(customer);

		cartDetails.setCustomerId(cust_id);
		cartDetails.setCartId(KeyHelper.getCartID());
		// int cart_id=cartDetails.getCartId();
		shopService.saveCustomerCartDetails(cartDetails);
		return "sign-in";

	}

	@RequestMapping(value = "/login")
	public String login() {
		return "sign-in";
	}

	@RequestMapping(value = "/validation")
	public @ResponseBody ModelAndView validateCust(@RequestParam("uname") String userId,
			@RequestParam("pass") String password, HttpServletRequest request, Model model, HttpSession session,
			HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		boolean valid = shopService.validateCustomer(userId, password);
		if (valid == true) {
			List<Object[]> list = shopService.getCustomerID(userId);
			int customerId = 0;
			String customerName = null;
			for (Object[] cust : list) {
				customerId = (Integer) cust[0];
				customerName = (String) cust[1];
			}
			session.setAttribute("customerName", customerName);
			session.setAttribute("custId", customerId);
			int cartId = shopService.getCartID(customerId);
			session.setAttribute("cartId", cartId);
			List<Product> products = shopService.getProductDetails();
			request.setAttribute("productDetails", products);
			mv.setViewName("shopping-home");
			return mv;
		}
		mv.setViewName("sign-in");
		return mv;
	}

	@RequestMapping(value = "/home")
	public ModelAndView showHome(ModelAndView mv, HttpServletRequest request) {
		List<Product> products = shopService.getProductDetails();
		request.setAttribute("productDetails", products);
		mv.setViewName("shopping-home");
		return mv;
	}

	// int currentUser;
	List<Product> cartProduct = new ArrayList<Product>();

	@RequestMapping(value = "/cart", method = RequestMethod.GET)

	public String addProduct(@RequestParam("pid") int productId, @RequestParam("pname") String productName,
			HttpSession session, HttpServletRequest request) {

		int customerId = (Integer) session.getAttribute("custId");
		int cartId = (Integer) session.getAttribute("cartId");
		shopService.addCart(cartId, customerId, productId, productName);
		Product cartProd = shopService.getCartProductDetails(productId);
		// session.setAttribute("productId", productID);

		cartProduct.add(cartProd);
		session.setAttribute("cartProductDetails", cartProduct);
		return "added";
	}

	@RequestMapping(value = "/myCart")
	public String showCartDetails(HttpSession session) {
		return "cartList";
	}

	@RequestMapping(value = "/myCartDetails")
	public String showCartAfterPayment(HttpSession session) {
		int cartId = (Integer) session.getAttribute("cartId");

		shopService.deleteMyCart(cartId);
		return "cartList";
	}

	CustomerOrder order = new CustomerOrder();
	CustomerCartDetails cartDetail = new CustomerCartDetails();

	@RequestMapping(value = "/buyNow", method = RequestMethod.GET)
	public String buyProduct(HttpSession session, @RequestParam("pid") int productId) {

		int customerId = (Integer) session.getAttribute("custId");
		int cartId = (Integer) session.getAttribute("cartId");

		int order_id = shopService.placeOrder(customerId, cartId);
		// status.setOrderId(order_id);
		shopService.orderedProduct(order_id, productId);

		shopService.deleteMyCart(cartId);

		cartProduct = new ArrayList<Product>();
		session.setAttribute("cartProductDetails", cartProduct);
		session.setAttribute("orderId", order_id);
		return "orders";
	}

	@RequestMapping(value = "/payNow", method = RequestMethod.GET)
	public String buyProductFromCart(HttpSession session) {
		int customerId = (Integer) session.getAttribute("custId");
		int cartId = (Integer) session.getAttribute("cartId");
		List<Integer> productId = (List<Integer>) session.getAttribute("cartProductIds");

		int order_id = shopService.placeOrder(customerId, cartId);
		// status.setOrderId(order_id);
		for (int id : productId) {
			shopService.orderedProduct(order_id, id);
		}

		shopService.deleteMyCart(cartId);

		cartProduct = new ArrayList<Product>();
		session.setAttribute("cartProductDetails", cartProduct);
		session.setAttribute("orderId", order_id);
		return "orders";
	}
	
	@RequestMapping(value = "/orderSummary")
	public String showOrderSummary(HttpSession session) {
		List<Product> orderedProductDetails = new ArrayList<Product>();
		int orderId = (Integer) session.getAttribute("orderId");
		CustomerOrder order=shopService.getOrderDetails(orderId);
		Timestamp orderDate=(Timestamp) order.getOrderDate();
		session.setAttribute("ordDate", orderDate);
		List<Integer> orderedProductIds = shopService.getOrderProductId(orderId);
		
		for (int proId : orderedProductIds) {
			Product orderSummaryDetails = shopService.getOrderProductDetails(proId);
			orderedProductDetails.add(orderSummaryDetails);
		}
		session.setAttribute("OrderSummary", orderedProductDetails);
		
		return "summary";
	}
	@RequestMapping(value = "/status")
	public String seeStatus() {
		return "receive";

	}
	@RequestMapping(value = "/showStatus")
	public String showStatus(@RequestParam("receivingStatus") String receiver,HttpSession session) {
		int orderId=(Integer) session.getAttribute("orderId");
		if(receiver.equalsIgnoreCase("Yes")) {
			shopService.updateStatus(orderId);
			CustomerOrder order=shopService.getOrderDetails(orderId);
			String status=order.getStatus();
			session.setAttribute("status", status);
			
		}else if(receiver.equalsIgnoreCase("No")) {
		CustomerOrder order=shopService.getOrderDetails(orderId);
		String status=order.getStatus();
		session.setAttribute("status", status);
		}
		return "status";

	}
	


	@RequestMapping(value = "/logout")
	public String logoutFromShoppingCart() {
		return "logout";

	}

}
