package com.hcl.modal;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.hcl.Service.KeyHelper;
@Entity
public class CustomerCartDetails {
	@Id
	private int customerId;
	private int cartId;
	public int getCustomerId() {
		return customerId;
	}

	
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public void setCartId(int cartId) {
		this.cartId = cartId;
	}


	public int getCartId() {
		return cartId;
	}
	
	
}
