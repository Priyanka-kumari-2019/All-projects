package com.hcl.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.hcl.Service.KeyHelper;

@Entity
public class ShoppingCustomer {
	@Id
	private int customerId;
	@Column(unique = true)
	private String name;
	private String address;
	@Column(unique = true, length = 10, nullable = false)

	private long phoneNumber;
	@Column(unique = true)
	private String emailId;
	@Column(unique = true)
	private String password;
	
	

	public int getCustomerId() {
	
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
