package com.hcl.modal;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Cart {
	
	@EmbeddedId
	private CartKey cartProdId;
	private int userId;
	private String productName;
	//private int quantity;
	public CartKey getCartProdId() {
		return cartProdId;
	}
	public void setCartProdId(CartKey cartProdId) {
		this.cartProdId = cartProdId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	
	
}
