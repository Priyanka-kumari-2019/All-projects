package com.hcl.modal;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OrderedProductDetails {
@Id
	public OrderKey orderProductId;

	public OrderKey getOrderProductId() {
		return orderProductId;
	}

	public void setOrderProductId(OrderKey orderProductId) {
		this.orderProductId = orderProductId;
	}
	
	
	
	
}
