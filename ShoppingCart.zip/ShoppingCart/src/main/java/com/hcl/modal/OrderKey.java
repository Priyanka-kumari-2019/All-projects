package com.hcl.modal;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class OrderKey implements Serializable {
	private static final long serialVersionUID = 1L;
	private int orderId;

	private int ProductId;

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getProductId() {
		return ProductId;
	}

	public void setProductId(int productId) {
		ProductId = productId;
	}
}
