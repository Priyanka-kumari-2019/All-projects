var n=0;
function myInput() {
n=prompt("Enter value to pattern");	
	
}
function patternFunction1(){
	var i,j;
	var pattern="";
	for( i=1;i<=n;i++){
		for( j=1;j<=i;j++){
			
		pattern+=j;
		}
		pattern+="<br/>";
		
		document.getElementById("pa1").innerHTML=pattern;
	}
}

function patternFunction2(){
	var i,j;
	var pattern="";
	for(i=n;i>0;i--){
		for(j=i;j>0;j--){
			pattern+=i;	
		}
		pattern+="<br/>";
		document.getElementById("pa2").innerHTML=pattern;
	}
}

function patternFunction3(){
	var i,j;
	var pattern="";
	for( i=0;i<n;i++){
		for( j=n;j>i;j--){
			pattern+=j;	
		}
		pattern+="<br/>";
		document.getElementById("pa3").innerHTML=pattern;
	}

}

function patternFunction4(){
	var i,j;
	var pattern="";
	for( i=0;i<n;i++){
		for(j=n;j>i;j--){
			pattern+=n;	
			
		}
		pattern+="<br/>";
		document.getElementById("pa4").innerHTML=pattern;
	}

}