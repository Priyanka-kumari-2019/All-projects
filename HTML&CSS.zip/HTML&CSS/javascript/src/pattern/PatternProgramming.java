package pattern;

public class PatternProgramming {
	public static void main(String args[]){
		for(int i=5;i>0;i--){
			for(int j=i;j>0;j--){
				System.out.print(i);
			}
			System.out.println();
	}
		
		for(int i=0;i<5;i++){
			for(int j=5;j>i;j--){
				System.out.print(j);
			}
			System.out.println();
		}
		
		for(int i=0;i<5;i++){
			for(int j=5;j>i;j--){
				System.out.print(5);
			}
			System.out.println();
		}
	}
	
	

}
