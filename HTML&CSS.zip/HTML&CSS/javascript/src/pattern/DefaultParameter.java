package pattern;

public class DefaultParameter {
	int a;
	int b=10;
	public static void main(String args[]){
		DefaultParameter df=new DefaultParameter();
		df.display();
		
		}
	public void display(){
	//System.out.println(a);	
	add(a, b);
	}
	public void add(int a,int b){
		int sum=a+b;
		System.out.println("sum:"+sum);
	}
}
