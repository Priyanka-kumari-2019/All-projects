package pattern;

import java.time.LocalDate;
import java.util.Date;

public class DateDemo {

	public static void main(String[] args) {
		Date date=new Date(2019, 11, 11, 3, 40, 30);
		System.out.println(date);
		Date d=new Date(2019, 10, 11);
		System.out.println(d);
		//System.out.println(d.get);
		//System.out.println(date.toString());
		/*String.format("{M/d/yyyy}", date);
		System.out.println(String.format("{0:M/d/yyyy}", date));*/
		

	}

}
