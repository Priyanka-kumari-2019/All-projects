var objects;
function getDetails() {
	var xhttp = new XMLHttpRequest();

	xhttp.onreadystatechange = function() {
		if (xhttp.readyState == 4 && xhttp.status == 200) {
			// debugger;
			objects = JSON.parse(xhttp.response);
			// localStorage.setItem("employeeData", objects);
			console.log("objects-------", objects); /*
													 * for(var i=0;i<objects.length;i++){
													 * ex.innerHTML=objects[i].name; }
													 */
			// debugger;
			// var text="";
			/*
			 * for (var i = 0; i < objects.length; i++) {
			 * 
			 * var myObject = objects[i];
			 * 
			 * for (var x in myObject) { text += ( x + ": " + myObject[x] + "
			 * "); } ex.innerHTML=text; text += "<br/>";
			 *  }
			 */
			var myTable = "";

			var mainTable = "<table id='tab'><tr><th>Name</th><th>Address</th><th>PhoneNumber</th><th>Action</th></tr>";

			var mainTableEnd = "</table>";

			for (i = 0; i < objects.employees.length; i++) {

				// debugger;

				myTable = myTable
						+ "<tr><td>"
						+ objects.employees[i].name
						+ "</td><td>"
						+ objects.employees[i].address
						+

						"</td><td>"
						+ objects.employees[i].phoneNo
						+ "</td><td>"
						+ "<input type='button' id='bu' onclick='update("
						+ objects.employees[i]["id"]
						+ ")' value='update'>"
						+ "</td><td>"
						+ "<input type='button' id='bu' onclick='deleteCurrentRow("
						+ objects.employees[i]['id'] + ")' value='delete'>"
						+ "</td></tr>";

			}

			var AllInOne = mainTable + myTable + mainTableEnd
					+ "<p id='updated'>";

			document.getElementById("example").innerHTML = AllInOne;
		}
	};
	xhttp.open("GET", "JSONObjects.json", true);
	xhttp.send();

	// localStorage.setItem("datas", objects);
}

function update(row) {
	debugger;
	console.log("row---", row);

		for (i = 0; i < objects.employees.length; i++) {
			if (row == objects.employees[i].id) {
			updateForm(row);
			
		}
	}

}

function deleteCurrentRow(row) {
	// debugger;

	console.log("row---", row);
	console.log("objects----", objects);

	// document.getElementById('tab').deleteRow(row);
	// var empl=localStorage.getItem("employeeData");
	for (i = 0; i < objects.employees.length; i++) {
		if (row == objects.employees[i].id) {
			delete objects.employees[i];
			AfterDelete();

		}

	}
	console.log("objects----", objects);

}

function AfterDelete() {

	var myTable = "";

	var mainTable = "<table id='tab'><tr><th>Name</th><th>Address</th><th>PhoneNumber</th><th>Action</th></tr>";
	var mainTableEnd = "</table>";

	for (i = 0; i < objects.employees.length; i++) {

		// debugger;
		if (objects.employees[i] != null) {

			myTable = myTable + "<tr><td>" + objects.employees[i].name
					+ "</td><td>" + objects.employees[i].address +

					"</td><td>" + objects.employees[i].phoneNo + "</td><td>"
					+ "<input type='button' id='bu' onclick='update("
					+ objects.employees[i]["id"] + ")' value='update'>"
					+ "</td><td>"
					+ "<input type='button' id='bu' onclick='deleteCurrentRow("
					+ objects.employees[i]['id'] + ")' value='delete'>"
					+ "</td></tr>";

		}

		var AllInOne = mainTable + myTable + mainTableEnd;

		document.getElementById("example").innerHTML = AllInOne;
	}

}

function updateForm(row){
	inputBlocks = "<form action='update(row)>"
		+ "Name:<input type='text' id='name' >"
		+ "Address:<input type='text' id='address' >"
		+ "PhoneNumber:<input type='text' id='phone' >"+
		 "PhoneNumber:<input type='submit' id='phone' value='Submit'>"
		+"</form>";

	document.getElementById("updated").innerHTML = inputBlocks;
	
}