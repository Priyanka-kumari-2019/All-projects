function getDetails(){
	var xhttp=new XMLHttpRequest();
	xhttp.open("GET","JSONObjects.json",true);
	xhttp.onreadystatechange=function(){
		if(xhttp.readyState==4 && xhttp.status==200){
			//debugger;
			var objects=JSON.parse(xhttp.response);
			var ex=document.getElementById("example");
			/*for(var i=0;i<objects.length;i++){
			ex.innerHTML=objects[i].name;
			}*/
			debugger;
			 var text="";
			
			 for (var i = 0; i < objects.length; i++) {
				
		            var myObject = objects[i];
		            
		            for (var x in myObject) {
		                text += ( x + ": " + myObject[x] + " ");
		            }
		            ex.innerHTML=text;
		            text += "<br/>";
		            
		        }
		}
	};
	
	xhttp.send();
}