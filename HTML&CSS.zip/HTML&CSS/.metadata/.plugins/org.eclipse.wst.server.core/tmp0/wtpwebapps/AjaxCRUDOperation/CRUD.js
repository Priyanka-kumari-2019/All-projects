function onFormSubmit(){
	debugger;
var formData=getFormDetails();
insertData(formData);
}
function getFormDetails() {
	var formData={};
	debugger;
	formData["name"]=document.getElementById("fName").value;
	formData["address"]=document.getElementById("addr").value;
	formData["phone"]=document.getElementById("ph").value;
	return formData;
	
}

function insertData(data){
	debugger;
	var list=document.getElementById("employeeData").getElementsByTagName('tbody');
	var newRow=list.insertRow(list.length);
	cell1=newRow.insertCell(0);
	cell1.innerHTML=data.fullName;
}