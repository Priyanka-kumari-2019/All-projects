package com.java8.welcome;

public interface Welcome {
	default void welcomeMethod(String name){
		System.out.println("Welcome "+name);
	}

}
