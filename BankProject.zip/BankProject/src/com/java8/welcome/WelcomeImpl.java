package com.java8.welcome;

public class WelcomeImpl implements Welcome {

}
