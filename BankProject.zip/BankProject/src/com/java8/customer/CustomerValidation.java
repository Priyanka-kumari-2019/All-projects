package com.java8.customer;

public class CustomerValidation {
	
	//Customer c=new Customer(customerName, emailId, phoneNumber, age, savingAccount, loanAccount);
     //Customer c=new Customer();
     
    

}
