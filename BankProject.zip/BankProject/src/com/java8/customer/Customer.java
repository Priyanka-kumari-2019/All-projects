package com.java8.customer;

import com.java8.Account.LoanAccount;
import com.java8.Account.SavingAccount;

public class Customer {
	public String customerName;
	public String emailId;
	public long phoneNumber;
	public int age;
	public SavingAccount savingAccount;
	public LoanAccount loanAccount;
	public Customer customer;

	/*
	 * public Customer() {
	 * 
	 * }
	 */

	public Customer(String customerName, String emailId, long phoneNumber, int age, SavingAccount savingAccount,
			LoanAccount loanAccount) {
		super();
		this.customerName = customerName;
		this.emailId = emailId;
		this.phoneNumber = phoneNumber;
		this.age = age;
		this.savingAccount = savingAccount;
		this.loanAccount = loanAccount;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public boolean ageCheck(int age) {
		boolean flag = false;
		if (age > 18) {
			flag = true; // System.out.println(age+ " Not a valid customer");

		}
		return flag;
	}

	public boolean phoneCheck(long phNumber) {
		boolean flag = false;
		int length = String.valueOf(phNumber).length();
		if (length == 10) {
			flag = true; // System.out.println(age+ " Not a valid customer");

		}
		return flag;
	}

	public boolean checkBalance() {
		boolean flag = false;
		
		if (savingAccount.balance>50000) {
			flag = true; // System.out.println(age+ " Not a valid customer");

		}
		return flag;
	}
	 /*@Override
     public String toString() {
         return "Customer{" +
                 "name='" + customerName + '\'' +
                 ", age=" + age +
                 '}';
     }*/

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((customerName == null) ? 0 : customerName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		return true;
	}

	
}
