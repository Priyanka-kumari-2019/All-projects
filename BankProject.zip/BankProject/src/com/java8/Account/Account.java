package com.java8.Account;

public interface Account {
	public void checkBalance();
	public void deposit(int depositAmount);
	

}
