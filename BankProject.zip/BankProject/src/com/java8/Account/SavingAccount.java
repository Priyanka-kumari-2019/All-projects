package com.java8.Account;

public class SavingAccount implements Account {
	public double balance;
	public String savingAccountNumber;
	static String sCode="71835";
	static long accNumber=10000;
	

	public SavingAccount() {
		
	}

	public SavingAccount(double balance) {
		this.balance = balance;
		accNumber++;
		savingAccountNumber=sCode+accNumber;
	}

	public String getSavingAccountNumber() {
		return savingAccountNumber;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	@Override
	public void checkBalance() {
		System.out.println("Saving balance is " + balance);

	}

	public void withdrawl(int withdrawAmount) {
		if (balance > withdrawAmount) {
			balance = balance - withdrawAmount;

		} else {
			System.out.println("Sorry, your account balance is low");
		}

	}

	@Override
	public void deposit(int depositAmount) {
		balance = balance + depositAmount;

	}

}
