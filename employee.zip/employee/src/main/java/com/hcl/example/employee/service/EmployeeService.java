package com.hcl.example.employee.service;

import java.util.Optional;

import com.hcl.example.employee.dto.EmployeeRequestDto;
import com.hcl.example.employee.modal.Employee;

public interface EmployeeService {
	public void saveEmployeeDetails(EmployeeRequestDto employeeRequestDto );
	public Iterable<Employee> getEmployeeDetails();
	public Optional<Employee> getSelectedEmployeeDetails(long sapId);

}
