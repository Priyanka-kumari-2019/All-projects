package com.hcl.example.employee.helper;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ProjectHelper {

	public static String getProject() {
		List<String> projects = new ArrayList<String>();
		projects.add("Developement project");
		projects.add("UI Design project");
		projects.add("Testing project");
		Random rand = new Random();
		return projects.get(rand.nextInt(projects.size()));

	}
}
