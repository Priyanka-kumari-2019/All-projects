package com.hcl.example.employee.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hcl.example.employee.modal.Employee;
@Repository
public interface EmployeeDao extends CrudRepository<Employee, Long>{

}
