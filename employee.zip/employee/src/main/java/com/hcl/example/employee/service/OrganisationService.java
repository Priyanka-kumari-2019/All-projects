package com.hcl.example.employee.service;

import java.util.List;
import java.util.Optional;

import com.hcl.example.employee.modal.Employee;
import com.hcl.example.employee.modal.Organisation;

public interface OrganisationService {
	public void saveOrganisationalDetails(Employee employee);

	public  List<Employee> getSelectedEmployees(long salary);

}
