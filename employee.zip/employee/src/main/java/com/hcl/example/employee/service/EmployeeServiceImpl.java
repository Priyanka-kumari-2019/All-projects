package com.hcl.example.employee.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.example.employee.dao.EmployeeDao;
import com.hcl.example.employee.dto.EmployeeRequestDto;
import com.hcl.example.employee.helper.SapIdHelper;
import com.hcl.example.employee.modal.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	OrganisationService organisationService;

	@Autowired
	EmployeeDao employeeDao;

	@Override
	public void saveEmployeeDetails(EmployeeRequestDto employeeRequestDto) {
		Employee employee = new Employee();
		employee.setId(SapIdHelper.generateSapId());
		employee.setName(employeeRequestDto.getName());
		employee.setAddress(employeeRequestDto.getAddress());
		employee.setDateOfBirth(employeeRequestDto.getDateOfBirth());
		employee.setEmailId(employeeRequestDto.getEmailId());
		employee.setPhoneNumber(employeeRequestDto.getPhoneNumber());
		Employee employeeDetails = employeeDao.save(employee);

		organisationService.saveOrganisationalDetails(employeeDetails);

	}

	@Override
	public Iterable<Employee> getEmployeeDetails() {
		return employeeDao.findAll();

	}

	@Override
	public Optional<Employee> getSelectedEmployeeDetails(long sapId) {

		return employeeDao.findById(sapId);
	}

}
