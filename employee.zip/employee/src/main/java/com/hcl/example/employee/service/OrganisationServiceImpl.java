package com.hcl.example.employee.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.example.employee.dao.OrganisationDao;
import com.hcl.example.employee.dto.EmployeeRequestDto;
import com.hcl.example.employee.helper.CompanyEmailIdHelper;
import com.hcl.example.employee.helper.ProjectHelper;
import com.hcl.example.employee.helper.SalaryHelper;
import com.hcl.example.employee.modal.Employee;
import com.hcl.example.employee.modal.Organisation;

@Service
public class OrganisationServiceImpl implements OrganisationService {
	@Autowired
	OrganisationDao organisationDao;
	
	@Autowired
	EmployeeService employeeService;

	@Override
	public void saveOrganisationalDetails(Employee employee) {
		Organisation organisation=new Organisation();
		organisation.setComanyId(CompanyEmailIdHelper.generateCompanyId(employee.getName()));
		organisation.setDateOfJoining(LocalDate.parse("2019-08-20"));
		organisation.setProjectName(ProjectHelper.getProject());
		organisation.setDesignation("Software Developer");
		organisation.setSapId(employee.getId());
		organisation.setSalary(SalaryHelper.getSalary());
		organisationDao.save(organisation);
		
	}

	@Override
	public List<Employee> getSelectedEmployees(long salary) {
		
		
		return organisationDao.findEmployeesAboveThisSalary(salary);
		
		/*
		 * //Organisation organisationDetails=organisationDao.findBySalary(salary);
		 * List<Organisation>
		 * organisationDetails=organisationDao.findEmployeesAboveThisSalary(salary);
		 * for(Organisation org:organisationDetails) {
		 * 
		 * Optional<Employee>
		 * employees=employeeService.getSelectedEmployeeDetails(org.getSapId());
		 * 
		 * } return employees;
		 */
		
	}

}
