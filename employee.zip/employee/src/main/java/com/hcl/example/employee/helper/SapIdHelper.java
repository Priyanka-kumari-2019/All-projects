package com.hcl.example.employee.helper;

public class SapIdHelper {
	static long sapId = 51830000L;

	public static long generateSapId() {
		sapId++;
		return sapId;

	}

}
