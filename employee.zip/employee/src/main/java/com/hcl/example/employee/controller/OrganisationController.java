package com.hcl.example.employee.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.example.employee.modal.Employee;
import com.hcl.example.employee.modal.Organisation;
import com.hcl.example.employee.service.OrganisationService;

@RestController
public class OrganisationController {

	@Autowired
	OrganisationService organisationService;

	@GetMapping("/employee/{salary}")
	public List<Employee> getSelectedEmployeeBySalary(@PathVariable long salary) {
		List<Employee> employeeDetails = organisationService.getSelectedEmployees(salary);

		return employeeDetails;
	}

}
