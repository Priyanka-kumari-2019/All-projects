package com.hcl.example.employee.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hcl.example.employee.modal.Employee;
import com.hcl.example.employee.modal.Organisation;
@Repository
public interface OrganisationDao extends CrudRepository<Organisation, Long> {
	//public Organisation findBySalary(long salary);
	@Query("select emp from Employee emp, Organisation org where org.salary > ?1 and emp.id=org.sapId ")
	public List<Employee> findEmployeesAboveThisSalary(long salary);


}
