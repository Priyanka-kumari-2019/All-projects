package com.hcl.springbootingtraining;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootingtrainingApplication {
	

	public static void main(String[] args) {
		SpringApplication.run(SpringbootingtrainingApplication.class, args);
		
	}

}
