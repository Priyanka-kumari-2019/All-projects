package com.hcl.springbootingtraining.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.hcl.springbootingtraining.entity.User;
import com.hcl.springbootingtraining.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;

	public String saveUser(User user) {
		userRepository.save(user);
		return "Success";
	}

	public List<User> getAllUsers() {
		return userRepository.findAll(Sort.by(Sort.Direction.ASC, "firstName"));
	}
	
	public User findById(Integer id) throws NullPointerException {
		Optional<User> users = userRepository.findById(id);
		if(users.isPresent()){
			return users.get();
		}else{
			throw new NullPointerException();
		}
	}

	public List<User> getUsersByFnameAndLname(String firstName, String lastName) {
		return userRepository.getUsersByQuery(firstName, lastName);
	}

	public Page<User> getUsersBypage(Integer pageNumber, Integer pageSize) {
		Pageable pageable = PageRequest.of(pageNumber, pageSize,
				Sort.by(Sort.Direction.ASC, "firstName"));
		return userRepository.findAll(pageable);
	}

}
