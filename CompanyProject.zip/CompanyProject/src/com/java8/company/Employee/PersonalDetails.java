package com.java8.company.Employee;

import java.time.LocalDate;
import java.util.Date;

public class PersonalDetails {
	private String name;
	private int age;
	private long phoneNumber;
	private LocalDate dateOfBirth;
	private String address;
	private String emailId;
	private float degreeAggregate;
	PersonalDetails personal;

	private PersonalDetails(String name, int age, long phoneNumber, LocalDate dateOfBirth, String address, String emailId,
			float degreeAggregate) {

		this.name = name;
		this.age = age;
		this.phoneNumber = phoneNumber;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
		this.emailId = emailId;
		this.degreeAggregate = degreeAggregate;

	}

	public static PersonalDetails getInstance(String name, int age, long phoneNumber, LocalDate dateOfBirth,
			String address, String emailId, float degreeAggregate) {

		return new PersonalDetails(name, age, phoneNumber, dateOfBirth, address, emailId, degreeAggregate);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public float getDegreeAggregate() {
		return degreeAggregate;
	}

	public void setDegreeAggregate(float degreeAggregate) {
		this.degreeAggregate = degreeAggregate;
	}

}