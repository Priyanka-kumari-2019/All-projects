package com.java8.company.Employee;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import com.java8.company.companyDetails.CompanyDetails;
import com.java8.company.companyDetails.ProjectDetails;

public class Employee {
	/*
	 * String name; int age; long phoneNumber; LocalDate dateOfBirth; String
	 * address; String emailId; float DegreeAggregate;
	 */
	ProjectDetails project;
	CompanyDetails company;
	PersonalDetails personal;
	// HashMap<String, String> skillSet=new HashMap<>();

	/*
	 * private Employee(String name, int age, long phoneNumber, LocalDate
	 * dateOfBirth , String address, String emailId, float degreeAggregate,
	 * HashMap<String, String> skillSet) {
	 * 
	 * this.name = name; this.age = age; this.phoneNumber = phoneNumber;
	 * this.dateOfBirth = dateOfBirth; this.address = address; this.emailId =
	 * emailId; this.DegreeAggregate = degreeAggregate; this.skillSet =
	 * skillSet;
	 * 
	 * }
	 */
	public static Employee init(String name, int age, long phoneNumber, LocalDate dateOfBirth, String address,
			String emailId, float degreeAggregate, HashMap<String, String> skillSet) {
		PersonalDetails personalDetails = PersonalDetails.getInstance(name, age, phoneNumber, dateOfBirth, address,emailId, degreeAggregate);

		CompanyDetails companyDetails = CompanyDetails.getInstance(name, skillSet);
		ProjectDetails project = ProjectDetails.getInstance();

		return new Employee(project, companyDetails, personalDetails);
	}

	private Employee(ProjectDetails project, CompanyDetails company, PersonalDetails personal) {
		super();
		this.project = project;
		this.company = company;
		this.personal = personal;
	}

}
