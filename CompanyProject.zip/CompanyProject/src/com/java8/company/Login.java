package com.java8.company;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import com.java8.company.Employee.Employee;
import com.java8.company.Employee.PersonalDetails;

import java.util.Date;

public class Login {

	public static void main(String[] args) {
		
		/*ArrayList<String> skillsLevel = new ArrayList<>();
		skillsLevel.add("Beginner");
		skillsLevel.add("Developer");
		skillsLevel.add("Expert");*/
		HashMap<String, String> skillSet = new HashMap<>();
		
		//String skill1=skillSet.put("C", "Beginner");
		String skill2=skillSet.put("C", "Expert");
		String skill3=skillSet.put("C++", "Beginner");
		//String skill4=skillSet.put("C++", "Expert");
		String skill5=skillSet.put("Java", "Beginner");
		
		//System.out.println(skillSet.keySet());

		ArrayList<Employee> employees = new ArrayList<>();
		
		// employees.add(new
		 employees.add(Employee.init("Priyanka",21,7201679190l,LocalDate.parse("1997-11-11"),"hajipur","priyanka.khjp@gmail.com",8.6f,skillSet));
		 employees.add(Employee.init("Priya",22,7202249190l,LocalDate.parse("1996-12-25"),"Patna","priya.rn@gmail.com",7.6f,skillSet));
		 employees.add(Employee.init("Anu",24,8277679190l,LocalDate.parse("1994-08-03"),"Bangalore","anu.jss@gmail.com",7.5f,skillSet));
		 employees.add(Employee.init("Amit",30,9977679190l,LocalDate.parse("1990-03-05"),"Pune","amit.k@gmail.com",6.9f,skillSet));
		 employees.add(Employee.init("Jyoti",23,7209079190l,LocalDate.parse("1995-10-09"),"Mumbai","jyoti.khjp@gmail.com",7.2f,skillSet));
		 employees.add(Employee.init("Anup",33,9109079190l,LocalDate.parse("1986-10-01"),"Chennai","anup.soni@gmail.com",6.2f,skillSet));
		 employees.add(Employee.init("Sakchi",22,7250679190l,LocalDate.parse("1997-01-09"),"Patna","sakchi.pat@gmail.com",8.2f,skillSet));
		 employees.add(Employee.init("Malti",23,7111179190l,LocalDate.parse("1995-10-09"),"Kerala","malti.khjp@gmail.com",7.2f,skillSet));
		 employees.add(Employee.init("Akshay",29,7190226851l,LocalDate.parse("1991-11-04"),"Mumbai","jyoti.ker@gmail.com",7.2f,skillSet));
		 employees.add(Employee.init("Akshara",19,7209079190l,LocalDate.parse("2000-10-09"),"Sikkim","akshara.sik@gmail.com",8.67f,skillSet));
	}

}
