package com.java8.company.companyDetails;

import java.time.LocalDate;
import java.util.ArrayList;

import java.util.HashMap;

import com.java8.company.Employee.PersonalDetails;

public class CompanyDetails {
	String sapId;
	static String code = "5183";
	static long id = 0001l;
	String loginId;

	String password;

	static long passNumber = 0001;

	double salary;
	LocalDate dateOfJoining ;
	HashMap<String, String> skillSet = new HashMap<>();

	CompanyDetails companyDetails;;

	/*
	 * private CompanyDetails() { SapId = code + companyId; companyId++;
	 * 
	 * //loginId = name + "@hcl.com"; password = pass + passNumber;
	 * passNumber++; }
	 */

	public CompanyDetails(String sapId, String loginId, String password, double salary,
			LocalDate dateOfJoining, HashMap<String, String> skillSet) {
		super();
		this.sapId = sapId;
		
		this.loginId = loginId;
		this.password = password;
		this.salary = salary;
		this.dateOfJoining = dateOfJoining;
		this.skillSet = skillSet;
	}

	public static CompanyDetails getInstance(String name, HashMap<String, String> skillSet) {
		return new CompanyDetails(showSapId(),generateCompanyId(name),generatePassword(name),getSalary(),showDateOfJoining(), skillSet);
	}

	public static String showSapId() {
		String sap = code + id;
		id++;
		return sap;

	}

	public static String generateCompanyId(String name) {
		String loginId = name + "@hcl.com";
		return loginId;

	}

	public static String generatePassword(String name) {
		String password = name + passNumber + "@";
		passNumber++;
		return password;

	}
	
	public static LocalDate showDateOfJoining() {
		LocalDate doj= LocalDate.parse("2019-08-20");
		return doj;
	}
	
	public static double getSalary(){
		double salary=30000d;
		return salary;
	}

	/*
	 * public CompanyDetails(String sapId) {
	 * 
	 * SapId = sapId; }
	 */
	/*
	 * public static CompanyDetails showSapId() { return new CompanyDetails(); }
	 */

	/*
	 * public CompanyDetails(String sapId, String loginId, String password,
	 * double salary, LocalDate dateOfJoining, HashMap<String,
	 * ArrayList<String>> skillSet) { super(); SapId = sapId; this.loginId =
	 * loginId; this.password = password; this.salary = salary;
	 * this.dateOfJoining = dateOfJoining; this.skillSet = skillSet;
	 * 
	 * return;
	 */

}
