package com.java8.company.companyDetails;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Random;

public class ProjectDetails {
	private String designation;
	private String reportingManager;
	private String projectCode;
	private String location;
	private String shift;
	
	
	private ProjectDetails(String designation, String reportingManager, String projectCode, String location,
			String shift) {
		super();
		this.designation = designation;
		this.reportingManager = reportingManager;
		this.projectCode = projectCode;
		this.location = location;
		this.shift = shift;
	}
	
	public static ProjectDetails getInstance() {
	
		return new ProjectDetails(getDesignation(),getReportingManager(),getProjectCode(),getLocation(),getShift());
	}
	public static String getDesignation(){
		ArrayList<String> designation=new ArrayList<>();
		designation.add("Developer");
		designation.add("Tester");
		Random random=new Random();
		return designation.get(random.nextInt(designation.size()));
		
	}
	
	public static String getReportingManager(){
		ArrayList<String> rm=new ArrayList<>();
		rm.add("Zaynab");
		rm.add("Amit");
		Random random=new Random();
		return rm.get(random.nextInt(rm.size()));
		
	}
	
	public static String getProjectCode(){
		ArrayList<String> code=new ArrayList<>();
		code.add("BLR");
		code.add("CHN");
		Random random=new Random();
		return code.get(random.nextInt(code.size()));
		
	}
	
	public static String getLocation(){
		ArrayList<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Chennai");
		Random random=new Random();
		return location.get(random.nextInt(location.size()));
		
	}
	public static String getShift(){
		ArrayList<String> shift=new ArrayList<>();
		shift.add("Day");
		shift.add("Night");
		Random random=new Random();
		return shift.get(random.nextInt(shift.size()));
		
	}
	

}
