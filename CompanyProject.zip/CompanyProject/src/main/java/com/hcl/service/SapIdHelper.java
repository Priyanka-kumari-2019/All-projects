package com.hcl.service;

import org.springframework.stereotype.Component;

import com.hcl.modal.Employee;
@Component

public class SapIdHelper {
	static String sap;
	static int comapnyId=1001;
	static String code="5183";
	public static String getSapID() {
		
	
		sap=code+comapnyId;
		comapnyId++;
		return sap;
	}
	
	
	
	
	

}
