package com.hcl.service;

import java.util.Random;

public class OrganisationHelper {

	public static String company_Id(String name) {
		String login_id;
		login_id = name + "@hcl.com";

		return login_id;

	}
	public static String getPassword(String name) {
	
		String pass=name+new Random().nextInt(1000)+"@";
		
		return pass;
		
	}
	public static String getRM() {
		String rm="Zaynab";
		return rm;
	}
	
	public static double getSalary() {
		double sal=30000.00;
		return sal;
				
	}
	
	public static String getLoc() {
		String location ="Bangalore";
		return location;
	}
	
	public static String getProjName() {
		String projName="Spring project";
		return projName;
	}

}
