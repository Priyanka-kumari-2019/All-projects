package com.hcl.service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.modal.Employee;
import com.hcl.modal.Organisation;
import com.hcl.modal.Project;

@Service
@Transactional

public class CompanyService {
	@Autowired
	public SessionFactory factory;

	/*
	 * public Session getSession() { return factory.getCurrentSession(); }
	 * 
	 * 
	 * 
	 * public Employee saveEmployee(Employee employee) {
	 * 
	 * getSession().save(employee); return employee; }
	 */
	public String saveEmployee(Employee employee) {
		
		employee.setSapId("5183"+new Random().nextInt(1000));
		Session session = factory.openSession();// get sap id before this
		Transaction tx = null;

		try {

			tx = session.beginTransaction();
			session.save(employee);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return employee.getSapId();
	}

	public int saveOrg(String sapID, String name) {
		// TODO Auto-generated method stub

		Organisation org = new Organisation();
		org.setSapId(sapID);
		org.setDateOfJoining(LocalDate.parse("2001-11-19"));
		org.setSalary(OrganisationHelper.getSalary());
		org.setLoginId(OrganisationHelper.company_Id(name));
		org.setPassword(OrganisationHelper.getPassword(name));
		org.setReportingManager(OrganisationHelper.getRM());
		Session session = factory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.save(org);
			tx.commit();
		} catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			ex.printStackTrace();
		} finally {
			session.close();
		}
		return 0;
	}

	public List<Organisation> getOranisationalDetails(String sapId) {

		Session session = factory.openSession();
		Transaction tx = null;
		List<Organisation> orgs = null;

		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("FROM Organisation where sapID = :sap");
			query.setParameter("sap", sapId);
			orgs = query.list();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return orgs;

	}

	public int saveProject(String sapID) {

		Project prj = new Project();
		prj.setSapId(sapID);
		prj.setProjectCode("PA" + sapID);
		prj.setLocation(OrganisationHelper.getLoc());
		prj.setProjectName(OrganisationHelper.getProjName());
		Session session = factory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.save(prj);
			tx.commit();
		} catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			ex.printStackTrace();
		} finally {
			session.close();
		}
		return 0;
	}

	public List<Project> getProjectDetails(String sapID) {

		Session session = factory.openSession();
		Transaction tx = null;
		List<Project> proj = null;

		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("FROM Project where sapID = :sap");
			query.setParameter("sap", sapID);
			proj = query.list();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return proj;


	}

}
