package com.hcl.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.modal.Employee;
import com.hcl.modal.Organisation;
import com.hcl.modal.Project;

@Service
@Transactional

public class CompanyService {
	@Autowired
	public SessionFactory factory;

	/*
	 * public Session getSession() { return factory.getCurrentSession(); } public
	 * Employee saveEmployee(Employee employee) {
	 * 
	 * getSession().save(employee); return employee; }
	 */

	public boolean validateUser(String userId, String pass) {
		Organisation org = new Organisation();
		Session session = factory.openSession();
		Transaction tx = null;
		boolean valid = false;
		//String sap=org.getSapId();
		try {

			tx = session.beginTransaction();
			Query query = session.createQuery("From Organisation where loginId = ? and password= ?");
			query.setParameter(0, userId);
			query.setParameter(1, pass);
			List<String> list = query.list();
			tx.commit();
			if (list != null && (list.size() > 0))
				valid = true;

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return valid;

	}

	public String saveEmployee(Employee employee) {

		employee.setSapId("5183" + new Random().nextInt(1000));
		Session session = factory.openSession();
		Transaction tx = null;

		try {

			tx = session.beginTransaction();
			session.save(employee);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return employee.getSapId();
	}

	public List<Employee> getEmployeeDetails(String sapId) {

		Session session = factory.openSession();
		Transaction tx = null;
		List<Employee> emp = null;

		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("FROM Employee where sapID = :sap");
			query.setParameter("sap", sapId);
			emp = query.list();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} /*
			 * finally { session.close(); }
			 */
		return emp;

	}

	public int saveOrg(String sapID, String name) {
		// TODO Auto-generated method stub

		Organisation org = new Organisation();
		org.setSapId(sapID);
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy",
				  Locale.ENGLISH);
				  
	  String dateInString = "20-Aug-2019"; 
	  try { Date date = formatter.parse(dateInString); 
	  org.setDateOfJoining(date);
	  System.out.println(date);
	  } catch(ParseException e) { 
       e.printStackTrace();
				  }
				 
		
		org.setSalary(OrganisationHelper.getSalary());
		org.setLoginId(OrganisationHelper.company_Id(name));
		org.setPassword(OrganisationHelper.getPassword(name));
		org.setReportingManager(OrganisationHelper.getRM());
		Session session = factory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.save(org);
			tx.commit();
		} catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			ex.printStackTrace();
		} 
			  finally { session.close(); }
			 
		return 0;
	}

	public List<Organisation> getOranisationalDetails(String sapId) {

		Session session = factory.openSession();
		Transaction tx = null;
		List<Organisation> orgs = null;

		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("FROM Organisation where sapID =?");
			query.setParameter(0, sapId);
			orgs = query.list();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

		return orgs;

	}

	public int saveProject(String sapID,String name) {

		Project prj = new Project();
		prj.setSapId(sapID);
		prj.setHclID(OrganisationHelper.company_Id(name));
		prj.setProjectCode("PA" + sapID);
		prj.setLocation(OrganisationHelper.getLoc());
		prj.setProjectName(OrganisationHelper.getProjName());
		Session session = factory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.save(prj);
			tx.commit();
		} catch (HibernateException ex) {
			if (tx != null)
				tx.rollback();
			ex.printStackTrace();
		} finally {
			session.close();
		}

		return 0;
	}

	public List<Project> getProjectDetails(String sapID) {

		Session session = factory.openSession();
		Transaction tx = null;
		List<Project> proj = null;

		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("FROM Project where sapID = :sap");
			query.setParameter("sap", sapID);
			proj = query.list();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return proj;

	}

	public void setUpdatedMail(String mail,String name) {

		Session session = factory.openSession();
		Transaction tx = null;
		//List<Organisation> orgs = null;

		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("update Employee e set e.emailId=? where e.name=?");
			query.setParameter(0, mail);
			query.setParameter(1, name);
			query.executeUpdate();
			//orgs = query.list();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

		

	}

}
