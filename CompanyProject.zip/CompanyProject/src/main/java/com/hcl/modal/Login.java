package com.hcl.modal;

public class Login {
	String uname;
	String password;

}
