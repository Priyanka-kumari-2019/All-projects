package com.hcl.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Project {
	@Id

	@Column(unique = true)
	private String sapId;
	@Column(unique = true)
	private String hclID;
	
	private String projectName;
	
	private String projectCode;
	
	private String location;
	
	public String getHclID() {
		return hclID;
	}
	public void setHclID(String hclID) {
		this.hclID = hclID;
	}
	
	
	public String getSapId() {
		return sapId;
	}
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	

}
