package com.hcl.controller;

import java.awt.Dialog.ModalExclusionType;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.modal.Employee;
import com.hcl.modal.Login;
import com.hcl.modal.Organisation;
import com.hcl.modal.Project;
import com.hcl.service.CompanyService;

@Controller
public class CompanyController {
	@Autowired
	CompanyService companyService;

	/*
	 * @RequestMapping("/login") public String login(Model m) { Login log = new
	 * Login(); m.addAttribute("loginDetails", log); return "login-page"; }
	 */

	@RequestMapping("/registeration")
	public String employeeForm(Model model) {

		Employee employee = new Employee();
		model.addAttribute("employeeDetails", employee);

		return "personal";
	}

	@RequestMapping(value = "/submitForm", method = RequestMethod.POST)
	public ModelAndView submitForm(@Valid @ModelAttribute("employeeDetails") Employee employee, BindingResult br,
			HttpServletRequest request, HttpSession session, Model m) {

		ModelAndView mv = new ModelAndView();
		if (br.hasErrors()) {
			mv.setViewName("personal");
			return mv;
		}

		String sapID = companyService.saveEmployee(employee);
		session.setAttribute("SapId", sapID);
        session.setAttribute("name", employee.getName());
		companyService.saveOrg(sapID, employee.getName());
		companyService.saveProject(sapID,employee.getName());

		Login log = new Login();

		m.addAttribute("loginDetails", log);
		mv.setViewName("login-page");
		return mv;

	}

	@RequestMapping(value = "/validate", method = RequestMethod.POST)

	public ModelAndView loginsuccess(@Valid @ModelAttribute("loginDetails") Login log, BindingResult br,
			HttpServletRequest request) {
		/*
		 * String userId = request.getParameter("username"); String password =
		 * request.getParameter("password");
		 */ ModelAndView mv = new ModelAndView("log");
		if (br.hasErrors()) {
			mv.setViewName("login-page");
		}

		boolean valid = companyService.validateUser(log.getUserId(), log.getPassword());
		if (valid == true)
			mv.setViewName("success-page");
		else
			mv.setViewName("login-page");
		return mv;
	}
	
	@RequestMapping(value = "/login")
	public ModelAndView login(ModelAndView mv) {
		mv.setViewName("login-page");
		return mv;
		
	}

	@RequestMapping(value = "/profile", method = RequestMethod.GET)
	public String showEmployeeDetails(HttpSession session) {
		String sap = (String) session.getAttribute("SapId");
		List<Employee> employeeProfile = companyService.getEmployeeDetails(sap);
		session.setAttribute("employeeDetails", employeeProfile);
		return "profile";

	}

	@RequestMapping(value = "/organisation", method = RequestMethod.GET)
	public String showOrganisationDetails(HttpSession session) {
		String sap = (String) session.getAttribute("SapId");
		List<Organisation> orgDetails = companyService.getOranisationalDetails(sap);
		session.setAttribute("organisationDetails", orgDetails);

		return "organisation";

	}

	@RequestMapping(value = "/project", method = RequestMethod.GET)
	public String showProjectDetails(HttpSession session) {
		String sap = (String) session.getAttribute("SapId");
		List<Project> projectDetails = companyService.getProjectDetails(sap);
		session.setAttribute("projDetails", projectDetails);
		return "project";

	}
	

	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String updateMail() {
		
		return "update";
	}
	@RequestMapping(value = "/addUpdate", method = RequestMethod.GET)
	public String update(@RequestParam("mail") String updatedMail,HttpSession session) {
		String sap = (String) session.getAttribute("SapId");
		String empName=(String) session.getAttribute("name");
		companyService.setUpdatedMail(updatedMail,empName);
		List<Employee> employeeProfile=companyService.getEmployeeDetails(sap);
		session.setAttribute("employeeDetails", employeeProfile);
		return "profile";
	}
	
}
