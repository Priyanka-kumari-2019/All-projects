package com.hcl.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.modal.Employee;
import com.hcl.modal.Login;
import com.hcl.modal.Organisation;
import com.hcl.modal.Project;
import com.hcl.service.CompanyService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	@Autowired
	CompanyService companyService;

	// private static final Logger logger =
	// LoggerFactory.getLogger(HomeController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	/*
	 * @RequestMapping(value = "/", method = RequestMethod.GET) public String
	 * home(Locale locale, Model model) {
	 * logger.info("Welcome home! The client locale is {}.", locale);
	 * 
	 * Date date = new Date(); DateFormat dateFormat =
	 * DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
	 * 
	 * String formattedDate = dateFormat.format(date);
	 * 
	 * model.addAttribute("serverTime", formattedDate );
	 * 
	 * return "home"; }
	 */
	/*
	 * @RequestMapping(value="/",method =RequestMethod.GET ) public ModelAndView
	 * hello(ModelAndView mv){ mv.setViewName("home"); mv.addObject("Welcome",
	 * "Welcome to MvC"); mv.addObject("serverTime", "hello to spring mvc"); return
	 * mv; }
	 */
	@RequestMapping("/login")
	public String login(Model m) {
		Login log =new Login(); 
		m.addAttribute("loginDetails", log);
		return "login-page";
	}
	
	
	
	@RequestMapping("/personal")
	public String bookingForm(Model model) {

		Employee employee = new Employee();
		model.addAttribute("employeeDetails", employee);

		return "personal";
	}

	@RequestMapping(value = "/submitForm", method = RequestMethod.POST)
	public ModelAndView submitForm(@Valid @ModelAttribute("employeeDetails") Employee employee, BindingResult br,
			HttpServletRequest request,HttpSession session) {
		ModelAndView mv = new ModelAndView();
		if (br.hasErrors()) {
			mv.setViewName("personal");
			return mv;
		}

		String sapID = companyService.saveEmployee(employee);

		companyService.saveOrg(sapID, employee.getName());
		List<Organisation> orgDetails = companyService.getOranisationalDetails(sapID);
		request.setAttribute("organisationDetails", orgDetails);
		
		  companyService.saveProject(sapID); 
		  List<Project> projectDetails = companyService.getProjectDetails(sapID);
		  
		  
		/* mv.addObject(orgDetails); mv.addObject(projectDetails); */
		  
		  session.setAttribute("projDetails", projectDetails);
		 

		mv.setViewName("organisation");

		return mv;

	}

	@RequestMapping(value = "/project", method = RequestMethod.GET)
	public String showProjectDetails() {
		
		return "project";

	}
}
