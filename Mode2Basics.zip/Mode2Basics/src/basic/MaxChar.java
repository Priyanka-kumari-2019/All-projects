package basic;

import java.util.Scanner;

public class MaxChar {
	static char maximumOcc;

	public static void main(String[] args) {
		int count = 1;
		int max = 0;
		char m=' ';
		System.out.println("Enter the String");
		Scanner sc = new Scanner(System.in);
		String text = sc.nextLine();
		for (int i = 0; i < text.length(); i++) {
			for (int j = 0; j < text.length(); j++) {
				if (text.charAt(i) != maximumOcc) {
					if (text.charAt(i) == text.charAt(j))
						count++;
					else if (count > max) {
						max = count;
						maximumOcc = text.charAt(i);
					}

				}

			}
			count = 0;

		}
		System.out.println("maximum occuring character is: " + maximumOcc);
	}

}
