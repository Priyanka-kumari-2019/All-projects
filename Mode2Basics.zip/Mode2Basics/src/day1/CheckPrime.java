package day1;

public class CheckPrime {
	public boolean prime(int num){
		int count=0;
		int flag;
		for(int i=1;i<=num;i++){
			int rem=num%i;
			if(rem==0)
			count++;
		}
		if(count==2)
			flag=1;
		return true;
	}

}
