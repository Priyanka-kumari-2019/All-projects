package day1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class CircularPrime {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		int n = sc.nextInt();
		ArrayList<Integer> arr = new ArrayList<>();
		for (; n != 0; n /= 10) {
			int dig = n % 10;
			arr.add(dig);

		}
		//System.out.println(arr);
		// Object[] digits = arr.toArray();
		Collections.reverse(arr);
		System.out.println(arr);
		// System.Array.Reverse(digits);

		Collections.rotate(arr, 1);
		System.out.println(arr);
/*
		Collections.rotate(arr, 1);
		System.out.println(arr);*/
		System.out.println("rotate end");
		int sum=0;
		/*for(int i:arr){
			sum+=arr[i];
		}
*/
		// ArrayList<String>newList = transform(arr, String::valueOf);
		/*List<String> newList = arr.stream().map(s -> String.valueOf(s)).collect(Collectors.toList());
		System.out.println(newList);*/
		// String string = Joiner.on("").join(newList);
		/*String str = null;
		for (String i : newList) {

			str += newList;
		}
		System.out.println(str);*/
		/*arr.toString();
		System.out.println(arr);*/
		//String result = arr.stream().collect(Collectors.joining("", "{", "}"));
		CheckPrime c=new CheckPrime();
		c.prime(n);
	}

}
