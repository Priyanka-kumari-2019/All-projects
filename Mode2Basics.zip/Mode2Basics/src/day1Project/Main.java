package day1Project;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Customer c=new Customer();
		System.out.println("Enter customer name");
		c.customerName=sc.nextLine();
		System.out.println("Enter email id");
		c.emailId=sc.nextLine();
		System.out.println("Enter age");
		c.age=sc.nextInt();
		System.out.println("Enter phone number");
		c.phoneNumber=sc.nextLong();
		

		
		SavingAccount savingAccount=new SavingAccount();
		System.out.println("Enter account Number");
		String accNumber=savingAccount.accountNumber;
		
		savingAccount.checkBalance();
		
		System.out.println("Enter the amount to withdraw");
		long withdrawAmount=sc.nextLong();
	    savingAccount.withdrawl(withdrawAmount);
	    
	    System.out.println("Enter the amount to deposit");
	    long depositAmount=sc.nextLong();
	    savingAccount.deposit(depositAmount);
		//System.out.println("Remaining balance after withdrawl is "+remainingAmount);
	    
	    LoanAccount loanAccount = new LoanAccount();
	    System.out.println("Do you want to check loan balance");
	    String check=sc.next();
	    if(check.equalsIgnoreCase("yes")){
		loanAccount.checkBalance();
		System.out.println("Enter amount to deposit in loan");
		long loanDepositAmount=sc.nextLong();
		loanAccount.deposit(loanDepositAmount);
	    }
		
	}

}
