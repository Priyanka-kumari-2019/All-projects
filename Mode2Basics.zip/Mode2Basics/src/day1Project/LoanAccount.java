package day1Project;

public class LoanAccount implements Account {
	//LoanAccount loanAccount;
	String loanAccountNumber;
	long loanBalance=30000;
	@Override
	public void checkBalance() {
		System.out.println("Your loan account balance is "+loanBalance);
		//return loanBalance;
	}

	@Override
	public void deposit(long depositAmount) {
		loanBalance=loanBalance-depositAmount;
		System.out.println("Loan amount after deposit is"+loanBalance);
		SavingAccount savingAccount = new SavingAccount();
		
		savingAccount.withdrawl(depositAmount);
		
		//return loanBalance;
		
		
	}

}
