package day1Project;

public interface Account {
	public void checkBalance();
	public void deposit(long depositAmount);
	

}
