package day1Project;

public class SavingAccount implements Account {
	static long balance = 50000;
	String accountNumber;
	//SavingAccount savingAccount;

	/*
	 * public long getBalance() { return balance; }
	 * 
	 * public void setBalance(long balance) { this.balance = balance; }
	 * 
	 */
	@Override
	public void checkBalance() {
		System.out.println("Your saving account balance is " + balance);
		// return balance;
	}

	public void withdrawl(long withdrawAmount) {
		if (balance > withdrawAmount) {
			balance = balance - withdrawAmount;
			System.out.println("Remaining balance in saving account is " + balance);
			// return balance;
		}else{
			System.out.println("Sorry, your account balance is low");
		}

	}

	@Override
	public void deposit(long depositAmount) {
		balance = balance + depositAmount;
		System.out.println("Saving amount after deposit is " + balance);
		// return balance;

	}

}
