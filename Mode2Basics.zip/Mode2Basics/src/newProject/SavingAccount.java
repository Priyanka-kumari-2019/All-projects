package newProject;

public class SavingAccount implements Account {
	double balance;

	String accountNumber;

	public SavingAccount(long savingAccountNumber) {
		super();
		this.balance = savingAccountNumber;
	}


	public SavingAccount(String accountNumber) {
		super();
		this.accountNumber = accountNumber;
	}


	public SavingAccount() {
		super();
	}


	public String getAccountNumber() {
		return accountNumber;
	}

	
	public double getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	@Override
	public void checkBalance() {
		System.out.println("Saving balance is " + balance);

	}

	public void withdrawl(int withdrawAmount) {
		if (balance > withdrawAmount) {
			balance = balance - withdrawAmount;

		} else {
			System.out.println("Sorry, your account balance is low");
		}

	}

	@Override
	public void deposit(int depositAmount) {
		balance = balance + depositAmount;

	}

}
