package newProject;

public interface Account {
	public void checkBalance();
	public void deposit(int depositAmount);
	

}
