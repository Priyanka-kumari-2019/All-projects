package newProject;

public class Customer {
	String customerName;
	String emailId;
	long phoneNumber;
	int age;
	SavingAccount savingAccount;
	LoanAccount loanAccount;

	public String getCustomerName() {
		return customerName;
	}

	public Customer(String customerName, String emailId, long phoneNumber, int age, SavingAccount savingAccount,
			LoanAccount loanAccount) {
		super();
		this.customerName = customerName;
		this.emailId = emailId;
		this.phoneNumber = phoneNumber;
		this.age = age;
		this.savingAccount = savingAccount;
		this.loanAccount = loanAccount;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	Account saving = new SavingAccount(5000);
	Account loan = new LoanAccount();

}
