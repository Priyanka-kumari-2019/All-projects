package newProject;

import java.util.ArrayList;

public class NetBanking {

	public static void main(String[] args) {
		ArrayList<Customer> customerList=new ArrayList<>();
		
		String accountNumber="8143500001";
		
		String accountNumberLoan="7143500001";
		long savingAccountNumber=Long.parseLong(accountNumber);
		long loanAccountNumber=Long.parseLong(accountNumberLoan);
		
		/*SavingAccount sa;
		LoanAccount la;		*/
	
		
		customerList.add(new Customer("Priyanka", "priyanka.khjp@gmail.com", 9134612450l, 15,new SavingAccount(savingAccountNumber++),new LoanAccount(loanAccountNumber++)));
		customerList.add(new Customer("Swathi", "swathi@hcl.com", 7245333561l, 20,new SavingAccount(savingAccountNumber++),new LoanAccount(loanAccountNumber++)));
		customerList.add(new Customer("Priyanka", "priyanka.s@hcl.com", 8123545672l, 22,new SavingAccount(savingAccountNumber++),new LoanAccount(loanAccountNumber++)));
		customerList.add(new Customer("Amit", "amitk@gmail.com", 9014550674l, 28,new SavingAccount(savingAccountNumber++),new LoanAccount(loanAccountNumber++)));
		customerList.add(new Customer("Anuradha", "anujss@gmail.com", 9867545l, 24,new SavingAccount(savingAccountNumber++),new LoanAccount(loanAccountNumber++)));
		customerList.add(new Customer("Jyoti", "jyoti@gmail.com", 9546741532l, 22,new SavingAccount(savingAccountNumber++),new LoanAccount(loanAccountNumber++)));
		customerList.add(new Customer("Ramesh", "ramesh.khjp@gmail.com", 990141234l, 31,new SavingAccount(savingAccountNumber++),new LoanAccount(loanAccountNumber++)));
		customerList.add(new Customer("Vanishree", "vani@hcl.com", 9786509867l, 11,new SavingAccount(savingAccountNumber++),new LoanAccount(loanAccountNumber++)));
		customerList.add(new Customer("Ragini", "ragini.sam@gmail.com", 9654324l, 34,new SavingAccount(savingAccountNumber++),new LoanAccount(loanAccountNumber++)));
		customerList.add(new Customer("Sandhya", "sandhya@hcl.com", 9670545321l, 24,new SavingAccount(savingAccountNumber++),new LoanAccount(loanAccountNumber++)));
		
		
		
		/*new Welcome(customerList.get(0).customerName) {
		}*/;
		
		Welcome w=new WelcomeImpl();
		w.welcomeMethod(customerList.get(0).customerName);
		
		
		for(Customer obj:customerList){
			obj.savingAccount.accountNumber = "SBI"+obj.savingAccount.accountNumber;	
			
		}
		
		System.out.println("saving account Number: "+customerList.get(0).savingAccount.accountNumber);
		System.out.println("Loan Account Number: "+customerList.get(0).loanAccount.loanAccountNumber);
		
		

	}

}
