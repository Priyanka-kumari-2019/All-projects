package newProject;

public class CustomerValidation {
	
	
	Account saving = new SavingAccount(5000);
	Account loan = new LoanAccount();


}
