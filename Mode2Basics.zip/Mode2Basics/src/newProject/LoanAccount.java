package newProject;

public class LoanAccount implements Account {

	long loanAccountNumber=1100;
	
	//long nextPersonAccountNumber = 1100;
	long loanBalance = 30000;

	public LoanAccount() {
		
		loanAccountNumber ++;
	}
	
	public LoanAccount(long loanAccountNumber) {
	
		this.loanAccountNumber = loanAccountNumber;
	}


	public long getLoanAccountNumber() {
		return loanAccountNumber;
	}

	public long getLoanBalance() {
		return loanBalance;
	}

	public void setLoanBalance(long loanBalance) {
		this.loanBalance = loanBalance;
	}

	@Override
	public void checkBalance() {
		System.out.println("Loan balance is " + loanBalance);

	}

	@Override
	public void deposit(int depositAmount) {
		loanBalance = loanBalance - depositAmount;

		/*
		 * SavingAccount savingAccount = new SavingAccount();
		 * 
		 * savingAccount.withdrawl(depositAmount);
		 */

		// return loanBalance;

	}

}
