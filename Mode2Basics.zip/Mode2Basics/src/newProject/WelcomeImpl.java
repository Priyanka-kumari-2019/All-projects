package newProject;

public class WelcomeImpl implements Welcome {

}
