package updatedProject;

public interface Account {
	public void checkBalance();
	public void deposit(int depositAmount);
	

}
