package updatedProject;

public class Customer {
	String customerName;
	String emailId;
	long phoneNumber;
	int age;
	SavingAccount savingAccount;
	LoanAccount loanAccount;
	Customer customer;

	/*
	 * public Customer() {
	 * 
	 * }
	 */

	public Customer(String customerName, String emailId, long phoneNumber, int age, SavingAccount savingAccount,
			LoanAccount loanAccount) {
		super();
		this.customerName = customerName;
		this.emailId = emailId;
		this.phoneNumber = phoneNumber;
		this.age = age;
		this.savingAccount = savingAccount;
		this.loanAccount = loanAccount;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public boolean ageCheck(int age) {
		boolean flag = false;
		if (age > 18) {
			flag = true; // System.out.println(age+ " Not a valid customer");

		}
		return flag;
	}

	public boolean phoneCheck(long phNumber) {
		boolean flag = false;
		int length = String.valueOf(phNumber).length();
		if (length == 10) {
			flag = true; // System.out.println(age+ " Not a valid customer");

		}
		return flag;
	}

	public boolean checkBalance() {
		boolean flag = false;
		
		if (savingAccount.balance>50000) {
			flag = true; // System.out.println(age+ " Not a valid customer");

		}
		return flag;
	}

}
