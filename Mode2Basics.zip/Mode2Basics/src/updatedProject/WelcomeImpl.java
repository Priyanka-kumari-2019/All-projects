package updatedProject;

public class WelcomeImpl implements Welcome {

}
