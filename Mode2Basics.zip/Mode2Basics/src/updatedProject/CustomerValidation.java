package updatedProject;

public class CustomerValidation {
	
	//Customer c=new Customer(customerName, emailId, phoneNumber, age, savingAccount, loanAccount);
     //Customer c=new Customer();
     
    

}
