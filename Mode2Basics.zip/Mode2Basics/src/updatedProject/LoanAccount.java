package updatedProject;

import newProject.SavingAccount;

public class LoanAccount implements Account {

	 String loanAccountNumber;
	static String lCode = "51835";
	static long number = 10000;

	double loanBalance;

	public LoanAccount(double loanBalance) {

		this.loanBalance = loanBalance;
		number++;
		loanAccountNumber = lCode + number;
	}

	public String getLoanAccountNumber() {
		return loanAccountNumber;
	}

	public double getLoanBalance() {
		return loanBalance;
	}

	public void setLoanBalance(double loanBalance) {
		this.loanBalance = loanBalance;
	}

	@Override
	public void checkBalance() {
		System.out.println("Loan balance is " + loanBalance);

	}

	@Override
	public void deposit(int depositAmount) {
		loanBalance = loanBalance - depositAmount;

		/*
		 * SavingAccount savingAccount = new SavingAccount();
		 * 
		 * savingAccount.withdrawl(depositAmount);
		 */

		// return loanBalance;
		System.out.println("Remaining loan balance is "+loanBalance);
		updatedProject.SavingAccount sa=new updatedProject.SavingAccount();
		sa.withdrawl(depositAmount);

	}

}
