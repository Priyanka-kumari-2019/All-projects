package updatedProject;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class NetBanking {
	
	public static void main(String[] args) {
		ArrayList<Customer> customerList = new ArrayList<>();

		double savingBalance = 50000;
		double loanBalance = 30000;
		customerList.add(new Customer("Priyanka", "priyanka.khjp@gmail.com", 9134612450l, 15,
				new SavingAccount(savingBalance), new LoanAccount(loanBalance)));
		customerList.add(new Customer("Swathi", "swathi@hcl.com", 7245333561l, 20, new SavingAccount(savingBalance),
				new LoanAccount(loanBalance)));
		customerList.add(new Customer("Priyanka", "priyanka.s@hcl.com", 8123545672l, 22,
				new SavingAccount(savingBalance), new LoanAccount(loanBalance)));
		customerList.add(new Customer("Amit", "amitk@gmail.com", 9014550674l, 28, new SavingAccount(savingBalance),
				new LoanAccount(loanBalance)));
		customerList.add(new Customer("Anuradha", "anujss@gmail.com", 9867545l, 24, new SavingAccount(savingBalance),
				new LoanAccount(loanBalance)));
		customerList.add(new Customer("Jyoti", "jyoti@gmail.com", 9546741532l, 22, new SavingAccount(savingBalance),
				new LoanAccount(loanBalance)));
		customerList.add(new Customer("Ramesh", "ramesh.khjp@gmail.com", 990141234l, 31,
				new SavingAccount(savingBalance), new LoanAccount(loanBalance)));
		customerList.add(new Customer("Vanishree", "vani@hcl.com", 9786509867l, 11, new SavingAccount(savingBalance),
				new LoanAccount(loanBalance)));
		customerList.add(new Customer("Ragini", "ragini.sam@gmail.com", 9654324l, 34, new SavingAccount(savingBalance),
				new LoanAccount(loanBalance)));
		customerList.add(new Customer("Sandhya", "sandhya@hcl.com", 9670545321l, 24, new SavingAccount(savingBalance),
				new LoanAccount(loanBalance)));

		// customerList.forEach(customer->System.out.println(customer.customerName));
		Welcome w = new WelcomeImpl();
		w.welcomeMethod(customerList.get(0).customerName);

		/*
		 * for(Customer cust:customerList){
		 * cust.savingAccount.savingAccountNumber="SBI"+cust.savingAccount.
		 * savingAccountNumber;
		 * cust.loanAccount.loanAccountNumber="SBI"+cust.loanAccount.
		 * loanAccountNumber; }
		 */

		
		 
		customerList.stream().map(customer -> "SBI" + customer.loanAccount.loanAccountNumber);
		customerList.forEach(cust -> System.out.println(cust.loanAccount.loanAccountNumber));

		// newCust.forEach(customer->System.out.println(customer.savingAccount.savingAccountNumber));
		// System.out.println();
		/*
		 * for(Customer cust:customerList){ boolean
		 * check=cust.ageCheck(cust.age); if(check==false){
		 * //System.out.println(cust.customerName+" is not eligible"); } }
		 */
		List<Customer> checkAge=customerList.stream().filter(customer -> customer.age > 18).collect(Collectors.toList());
		/*
		 * for(Customer cust:customerList){ boolean
		 * check=cust.phoneCheck(cust.phoneNumber); if(check==false){
		 * //System.out.println(cust.phoneNumber+" is not valid"); } }
		 */
		
		customerList.stream().filter(customer -> String.valueOf(customer.phoneNumber).length() == 10).collect(Collectors.toList());
		/*;

		customerList.get(0).savingAccount.withdrawl(2000);
		customerList.get(1).savingAccount.deposit(10000);
		/*
		 * System.out.println(customerList.get(5).loanAccount.loanAccountNumber)
		 * ; System.out.println(customerList.get(4).savingAccount.
		 * savingAccountNumber);
		 */
		/*
		 * for(Customer cust:customerList){ boolean check=cust.checkBalance();
		 * if(check==true){ System.out.println(cust.customerName);
		 * //System.out.println(cust.+" is not valid"); }
		 */

		customerList.stream().filter(customer -> customer.savingAccount.balance > 50000);

	}

}
